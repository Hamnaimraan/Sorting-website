var number;
document.getElementById("Generate").addEventListener("click", function() {
    number = generateRandom();
    var unsorted = document.getElementById("unsorted");
    unsorted.style.backgroundColor = "rgb(115, 47, 47)";
    document.getElementById("rand").innerHTML = "Unsorted Array:";
    document.getElementById("unsorted").innerHTML = number.join(", ");

})

document.getElementById("Quick").addEventListener("click", function() {
    if (number) {
        var sortednum = quickSort(number);
        var sorted = document.getElementById("sorted");
        sorted.style.backgroundColor = "rgb(115, 47, 47)";
        document.getElementById("sortType").innerHTML = " After Quick Sort:"
        document.getElementById("sorted").innerHTML = sortednum.join(",");
    } else {
        alert("Please generate numbers first.");
    }
})

document.getElementById("Merge").addEventListener("click", function() {
    if (number) {
        var sortednum = mergeSort(number);
        var sorted = document.getElementById("sorted");
        sorted.style.backgroundColor = "rgb(115, 47, 47)";
        document.getElementById("sortType").innerHTML = " After Merge Sort:"
        document.getElementById("sorted").innerHTML = sortednum.join(",");
    } else {
        alert("Please generate numbers first.");
    }
})

document.getElementById("Bubble").addEventListener("click", function() {
    if (number) {
        var sortednum = bubbleSort(number);
        var sorted = document.getElementById("sorted");
        sorted.style.backgroundColor = "rgb(115, 47, 47)";
        document.getElementById("sortType").innerHTML = " After Bubble Sort:"
        document.getElementById("sorted").innerHTML = sortednum.join(",");
    } else {
        alert("Please generate numbers first.");
    }
})

function generateRandom() {
    let number = [];
    for (let i = 1; i <= 100; i++) {
        number.push(Math.floor(Math.random() * 1000));


    }
    return number;

}

function quickSort(arr) {
    if (arr.length <= 1) {
        return arr;
    }

    const pivot = arr[arr.length - 1];
    const leftArr = [];
    const rightArr = [];

    for (let i = 0; i < arr.length - 1; i++) {
        if (arr[i] < pivot) {
            leftArr.push(arr[i]);
        } else {
            rightArr.push(arr[i]);
        }
    }

    return [...quickSort(leftArr), pivot, ...quickSort(rightArr)];
}

// Merge Sort Algorithm
function mergeSort(arr) {
    if (arr.length <= 1) {
        return arr;
    }

    const mid = Math.floor(arr.length / 2);
    const leftArr = arr.slice(0, mid);
    const rightArr = arr.slice(mid);

    return merge(mergeSort(leftArr), mergeSort(rightArr));
}

function merge(left, right) {
    let result = [];
    let leftIndex = 0;
    let rightIndex = 0;

    while (leftIndex < left.length && rightIndex < right.length) {
        if (left[leftIndex] < right[rightIndex]) {
            result.push(left[leftIndex]);
            leftIndex++;
        } else {
            result.push(right[rightIndex]);
            rightIndex++;
        }
    }

    return result.concat(left.slice(leftIndex)).concat(right.slice(rightIndex));
}

// Bubble Sort Algorithm
function bubbleSort(arr) {
    const len = arr.length;
    for (let i = 0; i < len - 1; i++) {
        for (let j = 0; j < len - 1 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                const temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    return arr;
}